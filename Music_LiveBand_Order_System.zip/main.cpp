#include <iostream>
#include <vector>
#include <string>

using namespace std;

// Service structure
struct Service {
    int id;
    string name;
    double price;
};

// Order structure
struct Order {
    string customerName;
    Service selectedService;
    string eventDate;
};

// Predefined services
vector<Service> services = {
    {1, "Solo Music Performance", 500.00},
    {2, "Live Band Performance", 1500.00},
    {3, "DJ Gig", 800.00},
    {4, "Full Event Package", 2500.00}
};

// Order history
vector<Order> orderHistory;

// Display services
void showServices() {
    cout << "\nAvailable Services:\n";
    for (const auto& service : services) {
        cout << service.id << ". " << service.name << " - ₦" << service.price << endl;
    }
}

// Take an order
void takeOrder() {
    Order newOrder;
    int serviceChoice;

    cout << "\nEnter Customer Name: ";
    getline(cin >> ws, newOrder.customerName);

    showServices();

    cout << "Select a service (1-" << services.size() << "): ";
    cin >> serviceChoice;

    if (serviceChoice < 1 || serviceChoice > services.size()) {
        cout << "Invalid service choice.\n";
        return;
    }

    newOrder.selectedService = services[serviceChoice - 1];

    cout << "Enter Event Date (e.g., 2025-06-01): ";
    cin >> newOrder.eventDate;

    orderHistory.push_back(newOrder);

    cout << "Order successfully recorded for " << newOrder.customerName << "!\n";
}

// Display all orders
void showOrders() {
    cout << "\nOrder History:\n";
    for (const auto& order : orderHistory) {
        cout << "Customer: " << order.customerName
             << " | Service: " << order.selectedService.name
             << " | Date: " << order.eventDate
             << " | Price: ₦" << order.selectedService.price << endl;
    }
}

// Main program loop
int main() {
    int choice;

    do {
        cout << "\n--- Music & Gig Service Order System ---\n";
        cout << "1. Take New Order\n";
        cout << "2. View All Orders\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                takeOrder();
                break;
            case 2:
                showOrders();
                break;
            case 3:
                cout << "Exiting... Thank you!\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 3);

    return 0;
}
