# 🎶 Music & Live Band Order Tracking System

This is a simple **C++ console application** for taking and tracking customer orders for music-related services such as **solo performances, live band gigs, DJ gigs, and full event packages**.

## Features
- 📦 Predefined services (Solo Performance, Live Band, DJ Gig, Full Package)
- 👤 Enter customer name and event date
- 🧾 Track all orders made in a session
- 🖥️ Simple console-based interface

## Compilation Instructions

### Requirements
- A C++ compiler (e.g., `g++`)

### To Compile:
```bash
g++ -o MusicOrderSystem main.cpp
```

### To Run:
```bash
./MusicOrderSystem
```

## Future Improvements
- Save/load from file
- Add login system
- Web/mobile integration

## Author Info
**Okwuiwe Alphonsus Jonas**  
Email: okwuiwejonas163@gmail.com  
Business: JOK TECH GLOBAL ENTERPRISE

## License
This project is licensed under the [MIT License](https://opensource.org/licenses/MIT).
