import {
  users,
  bands,
  venues,
  bookings,
  messages,
  reviews,
  availability,
  type User,
  type UpsertUser,
  type Band,
  type InsertBand,
  type Venue,
  type InsertVenue,
  type Booking,
  type InsertBooking,
  type Message,
  type InsertMessage,
  type Review,
  type InsertReview,
  type Availability,
  type InsertAvailability,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, ilike, inArray, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Band operations
  getBands(filters?: {
    location?: string;
    genres?: string[];
    minPrice?: number;
    maxPrice?: number;
    memberCount?: number;
    isAvailable?: boolean;
  }): Promise<Band[]>;
  getBand(id: number): Promise<Band | undefined>;
  createBand(band: InsertBand): Promise<Band>;
  updateBand(id: number, band: Partial<InsertBand>): Promise<Band>;
  deleteBand(id: number): Promise<void>;
  getBandsByOwner(ownerId: string): Promise<Band[]>;
  updateBandRating(bandId: number): Promise<void>;

  // Venue operations
  getVenues(): Promise<Venue[]>;
  getVenue(id: number): Promise<Venue | undefined>;
  createVenue(venue: InsertVenue): Promise<Venue>;
  updateVenue(id: number, venue: Partial<InsertVenue>): Promise<Venue>;
  deleteVenue(id: number): Promise<void>;
  getVenuesByOwner(ownerId: string): Promise<Venue[]>;

  // Booking operations
  getBookings(userId?: string): Promise<Booking[]>;
  getBooking(id: number): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: number, booking: Partial<Booking>): Promise<Booking>;
  getBookingsByBand(bandId: number): Promise<Booking[]>;
  getBookingsByUser(userId: string): Promise<Booking[]>;

  // Message operations
  getMessages(userId: string): Promise<Message[]>;
  getMessage(id: number): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<void>;
  getConversation(user1Id: string, user2Id: string, bookingId?: number): Promise<Message[]>;

  // Review operations
  getReviews(bandId?: number): Promise<Review[]>;
  getReview(id: number): Promise<Review | undefined>;
  createReview(review: InsertReview): Promise<Review>;
  getBandReviews(bandId: number): Promise<Review[]>;

  // Availability operations
  getBandAvailability(bandId: number, startDate: Date, endDate: Date): Promise<Availability[]>;
  createAvailability(availability: InsertAvailability): Promise<Availability>;
  updateAvailability(id: number, availability: Partial<Availability>): Promise<Availability>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Band operations
  async getBands(filters?: {
    location?: string;
    genres?: string[];
    minPrice?: number;
    maxPrice?: number;
    memberCount?: number;
    isAvailable?: boolean;
  }): Promise<Band[]> {
    let query = db.select().from(bands);
    
    const conditions = [];
    
    if (filters?.location) {
      conditions.push(ilike(bands.location, `%${filters.location}%`));
    }
    
    if (filters?.genres && filters.genres.length > 0) {
      conditions.push(sql`${bands.genres} && ${filters.genres}`);
    }
    
    if (filters?.minPrice !== undefined) {
      conditions.push(gte(bands.pricePerNight, filters.minPrice.toString()));
    }
    
    if (filters?.maxPrice !== undefined) {
      conditions.push(lte(bands.pricePerNight, filters.maxPrice.toString()));
    }
    
    if (filters?.memberCount !== undefined) {
      conditions.push(eq(bands.memberCount, filters.memberCount));
    }
    
    if (filters?.isAvailable !== undefined) {
      conditions.push(eq(bands.isAvailable, filters.isAvailable));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query.orderBy(desc(bands.averageRating));
  }

  async getBand(id: number): Promise<Band | undefined> {
    const [band] = await db.select().from(bands).where(eq(bands.id, id));
    return band;
  }

  async createBand(band: InsertBand): Promise<Band> {
    const [newBand] = await db.insert(bands).values(band).returning();
    return newBand;
  }

  async updateBand(id: number, band: Partial<InsertBand>): Promise<Band> {
    const [updatedBand] = await db
      .update(bands)
      .set({ ...band, updatedAt: new Date() })
      .where(eq(bands.id, id))
      .returning();
    return updatedBand;
  }

  async deleteBand(id: number): Promise<void> {
    await db.delete(bands).where(eq(bands.id, id));
  }

  async getBandsByOwner(ownerId: string): Promise<Band[]> {
    return await db.select().from(bands).where(eq(bands.createdById, ownerId));
  }

  async updateBandRating(bandId: number): Promise<void> {
    const reviewStats = await db
      .select({
        averageRating: sql<number>`AVG(${reviews.rating})`,
        totalReviews: sql<number>`COUNT(${reviews.id})`,
      })
      .from(reviews)
      .where(eq(reviews.bandId, bandId));

    if (reviewStats.length > 0) {
      await db
        .update(bands)
        .set({
          averageRating: reviewStats[0].averageRating?.toString() || '0',
          totalReviews: reviewStats[0].totalReviews || 0,
        })
        .where(eq(bands.id, bandId));
    }
  }

  // Venue operations
  async getVenues(): Promise<Venue[]> {
    return await db.select().from(venues).orderBy(asc(venues.name));
  }

  async getVenue(id: number): Promise<Venue | undefined> {
    const [venue] = await db.select().from(venues).where(eq(venues.id, id));
    return venue;
  }

  async createVenue(venue: InsertVenue): Promise<Venue> {
    const [newVenue] = await db.insert(venues).values(venue).returning();
    return newVenue;
  }

  async updateVenue(id: number, venue: Partial<InsertVenue>): Promise<Venue> {
    const [updatedVenue] = await db
      .update(venues)
      .set({ ...venue, updatedAt: new Date() })
      .where(eq(venues.id, id))
      .returning();
    return updatedVenue;
  }

  async deleteVenue(id: number): Promise<void> {
    await db.delete(venues).where(eq(venues.id, id));
  }

  async getVenuesByOwner(ownerId: string): Promise<Venue[]> {
    return await db.select().from(venues).where(eq(venues.ownerId, ownerId));
  }

  // Booking operations
  async getBookings(userId?: string): Promise<Booking[]> {
    let query = db.select().from(bookings);
    
    if (userId) {
      query = query.where(eq(bookings.bookerId, userId));
    }
    
    return await query.orderBy(desc(bookings.eventDate));
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(booking).returning();
    return newBooking;
  }

  async updateBooking(id: number, booking: Partial<Booking>): Promise<Booking> {
    const [updatedBooking] = await db
      .update(bookings)
      .set({ ...booking, updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return updatedBooking;
  }

  async getBookingsByBand(bandId: number): Promise<Booking[]> {
    return await db
      .select()
      .from(bookings)
      .where(eq(bookings.bandId, bandId))
      .orderBy(desc(bookings.eventDate));
  }

  async getBookingsByUser(userId: string): Promise<Booking[]> {
    return await db
      .select()
      .from(bookings)
      .where(eq(bookings.bookerId, userId))
      .orderBy(desc(bookings.eventDate));
  }

  // Message operations
  async getMessages(userId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        sql`${messages.senderId} = ${userId} OR ${messages.receiverId} = ${userId}`
      )
      .orderBy(desc(messages.createdAt));
  }

  async getMessage(id: number): Promise<Message | undefined> {
    const [message] = await db.select().from(messages).where(eq(messages.id, id));
    return message;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async markMessageAsRead(id: number): Promise<void> {
    await db.update(messages).set({ isRead: true }).where(eq(messages.id, id));
  }

  async getConversation(user1Id: string, user2Id: string, bookingId?: number): Promise<Message[]> {
    let query = db
      .select()
      .from(messages)
      .where(
        sql`(${messages.senderId} = ${user1Id} AND ${messages.receiverId} = ${user2Id}) OR (${messages.senderId} = ${user2Id} AND ${messages.receiverId} = ${user1Id})`
      );

    if (bookingId) {
      query = query.where(eq(messages.bookingId, bookingId));
    }

    return await query.orderBy(asc(messages.createdAt));
  }

  // Review operations
  async getReviews(bandId?: number): Promise<Review[]> {
    let query = db.select().from(reviews);
    
    if (bandId) {
      query = query.where(eq(reviews.bandId, bandId));
    }
    
    return await query.orderBy(desc(reviews.createdAt));
  }

  async getReview(id: number): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    return review;
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    
    // Update band rating after creating review
    await this.updateBandRating(review.bandId);
    
    return newReview;
  }

  async getBandReviews(bandId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.bandId, bandId))
      .orderBy(desc(reviews.createdAt));
  }

  // Availability operations
  async getBandAvailability(bandId: number, startDate: Date, endDate: Date): Promise<Availability[]> {
    return await db
      .select()
      .from(availability)
      .where(
        and(
          eq(availability.bandId, bandId),
          gte(availability.date, startDate),
          lte(availability.date, endDate)
        )
      )
      .orderBy(asc(availability.date));
  }

  async createAvailability(availabilityData: InsertAvailability): Promise<Availability> {
    const [newAvailability] = await db.insert(availability).values(availabilityData).returning();
    return newAvailability;
  }

  async updateAvailability(id: number, availabilityData: Partial<Availability>): Promise<Availability> {
    const [updatedAvailability] = await db
      .update(availability)
      .set(availabilityData)
      .where(eq(availability.id, id))
      .returning();
    return updatedAvailability;
  }
}

export const storage = new DatabaseStorage();
