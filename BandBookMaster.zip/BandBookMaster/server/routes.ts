import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertBandSchema, insertVenueSchema, insertBookingSchema, insertMessageSchema, insertReviewSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Band routes
  app.get('/api/bands', async (req, res) => {
    try {
      const filters = {
        location: req.query.location as string,
        genres: req.query.genres ? (req.query.genres as string).split(',') : undefined,
        minPrice: req.query.minPrice ? Number(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : undefined,
        memberCount: req.query.memberCount ? Number(req.query.memberCount) : undefined,
        isAvailable: req.query.isAvailable === 'true',
      };
      
      const bands = await storage.getBands(filters);
      res.json(bands);
    } catch (error) {
      console.error("Error fetching bands:", error);
      res.status(500).json({ message: "Failed to fetch bands" });
    }
  });

  app.get('/api/bands/:id', async (req, res) => {
    try {
      const bandId = Number(req.params.id);
      const band = await storage.getBand(bandId);
      
      if (!band) {
        return res.status(404).json({ message: "Band not found" });
      }
      
      res.json(band);
    } catch (error) {
      console.error("Error fetching band:", error);
      res.status(500).json({ message: "Failed to fetch band" });
    }
  });

  app.post('/api/bands', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bandData = insertBandSchema.parse({
        ...req.body,
        createdById: userId,
      });
      
      const band = await storage.createBand(bandData);
      res.status(201).json(band);
    } catch (error) {
      console.error("Error creating band:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid band data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create band" });
    }
  });

  app.put('/api/bands/:id', isAuthenticated, async (req: any, res) => {
    try {
      const bandId = Number(req.params.id);
      const userId = req.user.claims.sub;
      
      const existingBand = await storage.getBand(bandId);
      if (!existingBand) {
        return res.status(404).json({ message: "Band not found" });
      }
      
      if (existingBand.createdById !== userId) {
        return res.status(403).json({ message: "Not authorized to update this band" });
      }
      
      const bandData = insertBandSchema.partial().parse(req.body);
      const updatedBand = await storage.updateBand(bandId, bandData);
      res.json(updatedBand);
    } catch (error) {
      console.error("Error updating band:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid band data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update band" });
    }
  });

  app.get('/api/my-bands', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bands = await storage.getBandsByOwner(userId);
      res.json(bands);
    } catch (error) {
      console.error("Error fetching user bands:", error);
      res.status(500).json({ message: "Failed to fetch bands" });
    }
  });

  // Venue routes
  app.get('/api/venues', async (req, res) => {
    try {
      const venues = await storage.getVenues();
      res.json(venues);
    } catch (error) {
      console.error("Error fetching venues:", error);
      res.status(500).json({ message: "Failed to fetch venues" });
    }
  });

  app.post('/api/venues', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const venueData = insertVenueSchema.parse({
        ...req.body,
        ownerId: userId,
      });
      
      const venue = await storage.createVenue(venueData);
      res.status(201).json(venue);
    } catch (error) {
      console.error("Error creating venue:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid venue data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create venue" });
    }
  });

  // Booking routes
  app.get('/api/bookings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookings = await storage.getBookingsByUser(userId);
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.post('/api/bookings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookingData = insertBookingSchema.parse({
        ...req.body,
        bookerId: userId,
      });
      
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.put('/api/bookings/:id', isAuthenticated, async (req: any, res) => {
    try {
      const bookingId = Number(req.params.id);
      const userId = req.user.claims.sub;
      
      const existingBooking = await storage.getBooking(bookingId);
      if (!existingBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      if (existingBooking.bookerId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this booking" });
      }
      
      const bookingData = req.body;
      const updatedBooking = await storage.updateBooking(bookingId, bookingData);
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error updating booking:", error);
      res.status(500).json({ message: "Failed to update booking" });
    }
  });

  // Message routes
  app.get('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getMessages(userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messageData = insertMessageSchema.parse({
        ...req.body,
        senderId: userId,
      });
      
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  app.get('/api/conversations/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const otherUserId = req.params.userId;
      const bookingId = req.query.bookingId ? Number(req.query.bookingId) : undefined;
      
      const messages = await storage.getConversation(currentUserId, otherUserId, bookingId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  app.put('/api/messages/:id/read', isAuthenticated, async (req, res) => {
    try {
      const messageId = Number(req.params.id);
      await storage.markMessageAsRead(messageId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ message: "Failed to mark message as read" });
    }
  });

  // Review routes
  app.get('/api/reviews', async (req, res) => {
    try {
      const bandId = req.query.bandId ? Number(req.query.bandId) : undefined;
      const reviews = await storage.getReviews(bandId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post('/api/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        reviewerId: userId,
      });
      
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get('/api/bands/:id/reviews', async (req, res) => {
    try {
      const bandId = Number(req.params.id);
      const reviews = await storage.getBandReviews(bandId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching band reviews:", error);
      res.status(500).json({ message: "Failed to fetch band reviews" });
    }
  });

  // Search endpoint
  app.get('/api/search', async (req, res) => {
    try {
      const query = req.query.q as string;
      const filters = {
        location: query,
        genres: query ? [query] : undefined,
        isAvailable: true,
      };
      
      const bands = await storage.getBands(filters);
      res.json(bands);
    } catch (error) {
      console.error("Error searching:", error);
      res.status(500).json({ message: "Failed to search" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
