import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import type { Review } from "@shared/schema";

interface ReviewCardProps {
  review: Review;
}

export function ReviewCard({ review }: ReviewCardProps) {
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
      );
    }
    
    if (hasHalfStar) {
      stars.push(
        <Star key="half" className="h-4 w-4 text-yellow-400 fill-current opacity-50" />
      );
    }
    
    // Fill remaining stars
    for (let i = stars.length; i < 5; i++) {
      stars.push(
        <Star key={i} className="h-4 w-4 text-gray-300" />
      );
    }
    
    return stars;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Rating and Date */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="flex">
                {renderStars(Number(review.rating))}
              </div>
              <span className="text-sm font-medium text-gray-600">
                {Number(review.rating).toFixed(1)}
              </span>
            </div>
            <span className="text-sm text-gray-500">
              {formatDate(review.createdAt!)}
            </span>
          </div>

          {/* Review Comment */}
          <div>
            <p className="text-gray-700 leading-relaxed">
              "{review.comment}"
            </p>
          </div>

          {/* Reviewer Info */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center space-x-3">
              <Avatar className="h-10 w-10">
                <AvatarFallback>
                  {review.reviewerId.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h4 className="font-semibold text-gray-900">
                  Reviewer {review.reviewerId.slice(-4)}
                </h4>
                <p className="text-sm text-gray-600">Verified booking</p>
              </div>
            </div>
            
            {/* Event Type Badge */}
            <Badge variant="secondary" className="capitalize">
              {review.eventType}
            </Badge>
          </div>

          {/* Helpful Actions */}
          <div className="flex items-center space-x-4 text-sm text-gray-500 pt-2">
            <button className="hover:text-gray-700 transition-colors">
              👍 Helpful (0)
            </button>
            <button className="hover:text-gray-700 transition-colors">
              Report
            </button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
