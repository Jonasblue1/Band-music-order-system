import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { X } from "lucide-react";

interface FiltersPanelProps {
  isOpen: boolean;
  onClose: () => void;
  filters: any;
  onFiltersChange: (filters: any) => void;
}

export function FiltersPanel({ isOpen, onClose, filters, onFiltersChange }: FiltersPanelProps) {
  const [tempFilters, setTempFilters] = useState(filters);
  const [priceRange, setPriceRange] = useState([
    filters.minPrice || 0,
    filters.maxPrice || 10000
  ]);

  const genres = [
    "Rock", "Jazz", "Pop", "Country", "Electronic", 
    "Folk", "Blues", "Classical", "Hip Hop", "R&B"
  ];

  const memberCounts = [
    { value: 1, label: "Solo (1)" },
    { value: 2, label: "Duo (2)" },
    { value: 4, label: "Small Band (3-5)" },
    { value: 6, label: "Full Band (6+)" }
  ];

  const handleGenreChange = (genre: string, checked: boolean) => {
    const currentGenres = tempFilters.genres || [];
    let newGenres;
    
    if (checked) {
      newGenres = [...currentGenres, genre.toLowerCase()];
    } else {
      newGenres = currentGenres.filter((g: string) => g !== genre.toLowerCase());
    }
    
    setTempFilters(prev => ({ ...prev, genres: newGenres.length > 0 ? newGenres : undefined }));
  };

  const handleMemberCountChange = (value: string) => {
    setTempFilters(prev => ({ ...prev, memberCount: value === "all" ? undefined : Number(value) }));
  };

  const handlePriceRangeChange = (values: number[]) => {
    setPriceRange(values);
    setTempFilters(prev => ({
      ...prev,
      minPrice: values[0] > 0 ? values[0] : undefined,
      maxPrice: values[1] < 10000 ? values[1] : undefined
    }));
  };

  const applyFilters = () => {
    onFiltersChange(tempFilters);
    onClose();
  };

  const clearFilters = () => {
    const clearedFilters = {};
    setTempFilters(clearedFilters);
    setPriceRange([0, 10000]);
    onFiltersChange(clearedFilters);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Mobile Overlay */}
      <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={onClose} />
      
      {/* Panel */}
      <div className={`fixed inset-y-0 right-0 w-80 bg-white shadow-2xl transform transition-transform duration-300 z-50 overflow-y-auto ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      } lg:relative lg:translate-x-0 lg:w-80 lg:shadow-none lg:border-l`}>
        <div className="sticky top-0 bg-white border-b p-4 z-10">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">Filters</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="p-4 space-y-6">
          {/* Location Filter */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Location</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                placeholder="Enter city or zip code"
                value={tempFilters.location || ""}
                onChange={(e) => setTempFilters(prev => ({ ...prev, location: e.target.value || undefined }))}
              />
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="nearby"
                  checked={tempFilters.includeNearby || false}
                  onCheckedChange={(checked) => 
                    setTempFilters(prev => ({ ...prev, includeNearby: checked }))
                  }
                />
                <Label htmlFor="nearby" className="text-sm">Include nearby areas</Label>
              </div>
            </CardContent>
          </Card>

          {/* Price Range */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Price Range</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="px-2">
                <Slider
                  value={priceRange}
                  onValueChange={handlePriceRangeChange}
                  max={10000}
                  min={0}
                  step={100}
                  className="w-full"
                />
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>₦{priceRange[0].toLocaleString()}</span>
                <span>₦{priceRange[1].toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>

          {/* Genre Filter */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Genres</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {genres.map(genre => (
                <div key={genre} className="flex items-center space-x-2">
                  <Checkbox
                    id={genre}
                    checked={tempFilters.genres?.includes(genre.toLowerCase()) || false}
                    onCheckedChange={(checked) => handleGenreChange(genre, checked as boolean)}
                  />
                  <Label htmlFor={genre} className="text-sm">{genre}</Label>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Band Size */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Band Size</CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={tempFilters.memberCount?.toString() || "all"}
                onValueChange={handleMemberCountChange}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="all" />
                  <Label htmlFor="all" className="text-sm">Any Size</Label>
                </div>
                {memberCounts.map(count => (
                  <div key={count.value} className="flex items-center space-x-2">
                    <RadioGroupItem value={count.value.toString()} id={count.value.toString()} />
                    <Label htmlFor={count.value.toString()} className="text-sm">{count.label}</Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Availability */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Availability</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="available"
                  checked={tempFilters.isAvailable || false}
                  onCheckedChange={(checked) => 
                    setTempFilters(prev => ({ ...prev, isAvailable: checked }))
                  }
                />
                <Label htmlFor="available" className="text-sm">Available now</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="weekends" />
                <Label htmlFor="weekends" className="text-sm">Weekends only</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="short-notice" />
                <Label htmlFor="short-notice" className="text-sm">Short notice (&lt; 2 weeks)</Label>
              </div>
            </CardContent>
          </Card>

          {/* Apply Filters Button */}
          <div className="sticky bottom-0 bg-white pt-4 border-t space-y-2">
            <Button onClick={applyFilters} className="w-full">
              Apply Filters
            </Button>
            <Button variant="outline" onClick={clearFilters} className="w-full">
              Clear All
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
