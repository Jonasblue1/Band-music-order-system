import { useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import type { Booking } from "@shared/schema";

interface CalendarViewProps {
  bookings: Booking[];
}

export function CalendarView({ bookings }: CalendarViewProps) {
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  
  const bookingsByDate = useMemo(() => {
    const bookingMap = new Map<string, Booking[]>();
    
    bookings.forEach(booking => {
      const date = new Date(booking.eventDate);
      const dateKey = date.toDateString();
      
      if (!bookingMap.has(dateKey)) {
        bookingMap.set(dateKey, []);
      }
      bookingMap.get(dateKey)!.push(booking);
    });
    
    return bookingMap;
  }, [bookings]);
  
  const renderCalendarDays = () => {
    const days = [];
    
    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(
        <div key={`empty-${i}`} className="p-2 text-gray-400"></div>
      );
    }
    
    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentYear, currentMonth, day);
      const dateKey = date.toDateString();
      const dayBookings = bookingsByDate.get(dateKey) || [];
      const isToday = date.toDateString() === currentDate.toDateString();
      
      days.push(
        <div
          key={day}
          className={`p-2 text-center relative ${
            isToday ? 'bg-primary text-white rounded' : 'text-gray-800'
          } ${dayBookings.length > 0 ? 'font-bold' : ''}`}
        >
          <span>{day}</span>
          {dayBookings.length > 0 && (
            <div className="absolute bottom-0 right-0">
              <Badge 
                variant={dayBookings[0].status === 'confirmed' ? 'default' : 'secondary'}
                className="h-2 w-2 p-0 rounded-full"
              />
            </div>
          )}
        </div>
      );
    }
    
    return days;
  };
  
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <div className="text-center mb-4">
        <h4 className="font-semibold text-gray-900">
          {monthNames[currentMonth]} {currentYear}
        </h4>
      </div>
      
      <div className="grid grid-cols-7 gap-1 text-center text-sm mb-2">
        {dayNames.map(day => (
          <div key={day} className="font-medium text-gray-600 p-2">
            {day}
          </div>
        ))}
      </div>
      
      <div className="grid grid-cols-7 gap-1 text-sm">
        {renderCalendarDays()}
      </div>
      
      <div className="flex items-center space-x-4 text-sm mt-4">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-green-500 rounded mr-2"></div>
          <span className="text-gray-600">Confirmed</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-yellow-500 rounded mr-2"></div>
          <span className="text-gray-600">Pending</span>
        </div>
      </div>
    </div>
  );
}
