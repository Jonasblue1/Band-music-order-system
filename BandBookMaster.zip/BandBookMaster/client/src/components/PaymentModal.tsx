import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CreditCard, Lock, X, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  onPaymentSuccess: () => void;
  bookingDetails: {
    bandName: string;
    eventDate: string;
    eventTime: string;
    venue: string;
  };
}

export function PaymentModal({ 
  isOpen, 
  onClose, 
  amount, 
  onPaymentSuccess, 
  bookingDetails 
}: PaymentModalProps) {
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState<string>("credit-card");
  const [paymentStep, setPaymentStep] = useState<"payment" | "success">("payment");
  const [formData, setFormData] = useState({
    cardNumber: "",
    expiryDate: "",
    cvc: "",
    cardholderName: "",
  });

  const processPaymentMutation = useMutation({
    mutationFn: async (paymentData: any) => {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simulate random payment success/failure
      if (Math.random() > 0.1) { // 90% success rate
        return { 
          success: true, 
          transactionId: 'tx_' + Math.random().toString(36).substr(2, 9),
          message: "Payment processed successfully"
        };
      } else {
        throw new Error("Payment failed. Please check your card details and try again.");
      }
    },
    onSuccess: (data) => {
      setPaymentStep("success");
      setTimeout(() => {
        onPaymentSuccess();
        handleClose();
      }, 3000);
    },
    onError: (error: any) => {
      toast({
        title: "Payment failed",
        description: error.message || "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (paymentMethod === "credit-card") {
      if (!formData.cardNumber || !formData.expiryDate || !formData.cvc || !formData.cardholderName) {
        toast({
          title: "Missing information",
          description: "Please fill in all card details.",
          variant: "destructive",
        });
        return;
      }
    }

    processPaymentMutation.mutate({
      method: paymentMethod,
      amount,
      ...formData,
    });
  };

  const handleClose = () => {
    onClose();
    setPaymentStep("payment");
    setFormData({
      cardNumber: "",
      expiryDate: "",
      cvc: "",
      cardholderName: "",
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const renderPaymentForm = () => (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Payment Method Selection */}
      <div className="space-y-4">
        <Label className="text-base font-medium">Payment Method</Label>
        <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
          <div className="flex items-center space-x-2 p-3 border rounded-lg">
            <RadioGroupItem value="credit-card" id="credit-card" />
            <Label htmlFor="credit-card" className="flex items-center cursor-pointer flex-1">
              <CreditCard className="h-4 w-4 mr-2" />
              Credit/Debit Card
            </Label>
          </div>
          <div className="flex items-center space-x-2 p-3 border rounded-lg">
            <RadioGroupItem value="paypal" id="paypal" />
            <Label htmlFor="paypal" className="cursor-pointer flex-1">PayPal</Label>
          </div>
          <div className="flex items-center space-x-2 p-3 border rounded-lg">
            <RadioGroupItem value="apple-pay" id="apple-pay" />
            <Label htmlFor="apple-pay" className="cursor-pointer flex-1">Apple Pay</Label>
          </div>
        </RadioGroup>
      </div>

      {/* Credit Card Form */}
      {paymentMethod === "credit-card" && (
        <div className="space-y-4">
          <div>
            <Label htmlFor="card-number">Card Number</Label>
            <Input
              id="card-number"
              placeholder="1234 5678 9012 3456"
              value={formData.cardNumber}
              onChange={(e) => handleInputChange("cardNumber", e.target.value)}
              className="mt-1"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="expiry">Expiry Date</Label>
              <Input
                id="expiry"
                placeholder="MM/YY"
                value={formData.expiryDate}
                onChange={(e) => handleInputChange("expiryDate", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="cvc">CVC</Label>
              <Input
                id="cvc"
                placeholder="123"
                value={formData.cvc}
                onChange={(e) => handleInputChange("cvc", e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="cardholder-name">Cardholder Name</Label>
            <Input
              id="cardholder-name"
              placeholder="John Doe"
              value={formData.cardholderName}
              onChange={(e) => handleInputChange("cardholderName", e.target.value)}
              className="mt-1"
            />
          </div>
        </div>
      )}

      {/* Payment Summary */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-semibold mb-3">Payment Summary</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span>Band: {bookingDetails.bandName}</span>
          </div>
          <div className="flex justify-between">
            <span>Date: {bookingDetails.eventDate}</span>
          </div>
          <div className="flex justify-between">
            <span>Time: {bookingDetails.eventTime}</span>
          </div>
          <div className="flex justify-between">
            <span>Venue: {bookingDetails.venue}</span>
          </div>
          <Separator className="my-2" />
          <div className="flex justify-between font-bold text-lg">
            <span>Total Amount</span>
            <span className="text-primary">₦{amount.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Security Notice */}
      <div className="flex items-center space-x-2 text-sm text-gray-600 bg-blue-50 p-3 rounded-lg">
        <Lock className="h-4 w-4 text-blue-600" />
        <span>Your payment information is secure and encrypted</span>
      </div>

      {/* Submit Button */}
      <div className="flex justify-between">
        <Button type="button" variant="outline" onClick={handleClose}>
          Cancel
        </Button>
        <Button 
          type="submit" 
          disabled={processPaymentMutation.isPending}
          className="min-w-[140px]"
        >
          {processPaymentMutation.isPending ? (
            "Processing..."
          ) : (
            <>
              <Lock className="h-4 w-4 mr-2" />
              Pay ₦{amount.toFixed(2)}
            </>
          )}
        </Button>
      </div>
    </form>
  );

  const renderSuccessMessage = () => (
    <div className="text-center py-8">
      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
      <h3 className="text-xl font-bold text-gray-900 mb-2">Payment Successful!</h3>
      <p className="text-gray-600 mb-4">
        Your payment of ₦{amount.toFixed(2)} has been processed successfully.
      </p>
      <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
        <p className="text-sm text-green-800">
          You will receive a confirmation email shortly with your booking details.
        </p>
      </div>
      <p className="text-sm text-gray-500">
        This window will close automatically in a few seconds...
      </p>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <Lock className="h-5 w-5 mr-2" />
              {paymentStep === "payment" ? "Secure Payment" : "Payment Complete"}
            </span>
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        {paymentStep === "payment" ? renderPaymentForm() : renderSuccessMessage()}
      </DialogContent>
    </Dialog>
  );
}
