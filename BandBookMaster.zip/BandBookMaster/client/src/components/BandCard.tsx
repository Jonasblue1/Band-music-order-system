import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin } from "lucide-react";
import { Link } from "wouter";
import type { Band } from "@shared/schema";

interface BandCardProps {
  band: Band;
}

export function BandCard({ band }: BandCardProps) {
  const defaultImage = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250";
  
  return (
    <Card className="hover:shadow-xl transition duration-300 cursor-pointer overflow-hidden">
      <Link href={`/bands/${band.id}`}>
        <img 
          src={band.profileImages?.[0] || defaultImage} 
          alt={band.name} 
          className="w-full h-48 object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = defaultImage;
          }}
        />
      </Link>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <Link href={`/bands/${band.id}`}>
            <h3 className="font-bold text-lg text-gray-900 hover:text-primary cursor-pointer">
              {band.name}
            </h3>
          </Link>
          <div className="flex items-center">
            <Star className="text-yellow-400 h-4 w-4 fill-current" />
            <span className="text-sm text-gray-600 ml-1">
              {Number(band.averageRating || 0).toFixed(1)}
            </span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-2">
          {band.genres.slice(0, 2).map((genre, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {genre}
            </Badge>
          ))}
        </div>
        
        <div className="flex items-center text-gray-500 text-sm mb-3">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{band.location}</span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-lg font-bold text-primary">
            ₦{Number(band.pricePerNight).toLocaleString()}/night
          </span>
          <Link href={`/booking/${band.id}`}>
            <Button size="sm">
              Book Now
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
