import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Music, Calendar, CreditCard, Star, MapPin } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary">BandBooker Pro</h1>
              <div className="hidden md:block ml-10">
                <div className="flex items-baseline space-x-4">
                  <a href="#" className="text-gray-700 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">Find Bands</a>
                  <a href="#" className="text-gray-700 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">List Venue</a>
                  <a href="#" className="text-gray-700 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">How it Works</a>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button onClick={() => window.location.href = '/api/login'}>
                Log In
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-primary to-purple-600 py-16">
        <div className="absolute inset-0 bg-black opacity-40"></div>
        <div 
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1501386761578-eac5c94b800a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
          className="absolute inset-0"
        />
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Book Live Bands for Your Event</h1>
          <p className="text-xl text-gray-200 mb-8">Connect with talented musicians and create unforgettable experiences</p>
          
          {/* Search Form */}
          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Input placeholder="Location" className="pl-10" />
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                </div>
                <Input type="date" />
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="All Genres" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Genres</SelectItem>
                    <SelectItem value="rock">Rock</SelectItem>
                    <SelectItem value="jazz">Jazz</SelectItem>
                    <SelectItem value="pop">Pop</SelectItem>
                    <SelectItem value="country">Country</SelectItem>
                    <SelectItem value="electronic">Electronic</SelectItem>
                  </SelectContent>
                </Select>
                <Button className="bg-primary hover:bg-indigo-700">
                  <Search className="mr-2 h-4 w-4" />
                  Search Bands
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-4">
                <Button variant="ghost" size="sm" className="rounded-full">Wedding Bands</Button>
                <Button variant="ghost" size="sm" className="rounded-full">Corporate Events</Button>
                <Button variant="ghost" size="sm" className="rounded-full">Festival Acts</Button>
                <Button variant="ghost" size="sm" className="rounded-full">Private Parties</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Featured Bands */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Featured Bands</h2>
          <Button variant="ghost">View All →</Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[
            {
              name: "Thunder Road",
              genre: "Rock, Classic Rock",
              location: "Los Angeles, CA",
              price: "$2,500/night",
              rating: "4.9",
              image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
            },
            {
              name: "Smooth Jazz Collective",
              genre: "Jazz, Smooth Jazz",
              location: "New York, NY",
              price: "$1,800/night",
              rating: "4.8",
              image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
            },
            {
              name: "Electric Pulse",
              genre: "Electronic, EDM",
              location: "Miami, FL",
              price: "$3,200/night",
              rating: "4.7",
              image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
            },
            {
              name: "Harmony Hills",
              genre: "Folk, Acoustic",
              location: "Nashville, TN",
              price: "$1,200/night",
              rating: "4.9",
              image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
            }
          ].map((band, index) => (
            <Card key={index} className="hover:shadow-xl transition duration-300 cursor-pointer">
              <img src={band.image} alt={band.name} className="w-full h-48 object-cover rounded-t-lg" />
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-lg text-gray-900">{band.name}</h3>
                  <div className="flex items-center">
                    <Star className="text-yellow-400 h-4 w-4 fill-current" />
                    <span className="text-sm text-gray-600 ml-1">{band.rating}</span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-2">{band.genre}</p>
                <p className="text-gray-500 text-sm mb-3">{band.location}</p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-primary">{band.price}</span>
                  <Button size="sm" onClick={() => window.location.href = '/api/login'}>
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">How It Works</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Search & Discover</h3>
                <p className="text-gray-600">Browse through hundreds of professional bands and find the perfect match for your event.</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Book & Schedule</h3>
                <p className="text-gray-600">Check availability, send booking requests, and coordinate all the details seamlessly.</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Music className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Enjoy the Show</h3>
                <p className="text-gray-600">Sit back and enjoy an unforgettable performance at your event.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">What Our Users Say</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              rating: 5,
              comment: "Thunder Road absolutely killed it at our wedding! They read the crowd perfectly and had everyone dancing all night. Booking through BandBooker Pro was seamless.",
              reviewer: "Emily & David",
              eventType: "Wedding • Los Angeles",
              image: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=40&h=40"
            },
            {
              rating: 5,
              comment: "The Jazz Collective created the perfect atmosphere for our corporate event. Professional, talented, and exactly what we needed. The booking process was incredibly smooth.",
              reviewer: "Marcus Thompson",
              eventType: "Corporate Event • New York",
              image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=40&h=40"
            },
            {
              rating: 4.8,
              comment: "Electric Pulse brought incredible energy to our festival. The crowd was electric! Great communication throughout the booking process and they delivered exactly as promised.",
              reviewer: "Sarah Martinez",
              eventType: "Music Festival • Miami",
              image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=40&h=40"
            }
          ].map((review, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < review.rating ? 'fill-current' : ''}`} />
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">{review.rating}</span>
                </div>
                <p className="text-gray-700 mb-4">"{review.comment}"</p>
                <div className="flex items-center">
                  <img src={review.image} alt={review.reviewer} className="w-10 h-10 rounded-full object-cover" />
                  <div className="ml-3">
                    <h4 className="font-semibold text-gray-900">{review.reviewer}</h4>
                    <p className="text-sm text-gray-600">{review.eventType}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-primary py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Book Your Perfect Band?</h2>
          <p className="text-xl text-gray-200 mb-8">Join thousands of satisfied customers who found their ideal musicians through BandBooker Pro</p>
          <Button size="lg" variant="secondary" onClick={() => window.location.href = '/api/login'}>
            Get Started Today
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">BandBooker Pro</h3>
              <p className="text-gray-400 mb-4">Connecting talented musicians with amazing events worldwide.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Bands</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Create Profile</a></li>
                <li><a href="#" className="hover:text-white">Manage Bookings</a></li>
                <li><a href="#" className="hover:text-white">Payment Center</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Venues</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">List Your Venue</a></li>
                <li><a href="#" className="hover:text-white">Find Bands</a></li>
                <li><a href="#" className="hover:text-white">Event Management</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Help Center</a></li>
                <li><a href="#" className="hover:text-white">Contact Us</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 BandBooker Pro by Jonas Alphonsus Okwuiwe. Patent Pending - All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
