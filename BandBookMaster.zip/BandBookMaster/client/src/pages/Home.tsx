import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Navigation } from "@/components/Navigation";
import { BandCard } from "@/components/BandCard";
import { CalendarView } from "@/components/CalendarView";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, Calendar, MessageCircle, Bell } from "lucide-react";
import { Link } from "wouter";
import type { Band, Booking, Message } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();

  const { data: featuredBands = [], isLoading: bandsLoading } = useQuery({
    queryKey: ['/api/bands'],
  });

  const { data: upcomingBookings = [], isLoading: bookingsLoading } = useQuery({
    queryKey: ['/api/bookings'],
  });

  const { data: recentMessages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/messages'],
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Hero Search Section */}
      <div className="relative bg-gradient-to-r from-primary to-purple-600 py-16">
        <div className="absolute inset-0 bg-black opacity-40"></div>
        <div 
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1501386761578-eac5c94b800a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
          className="absolute inset-0"
        />
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Book Live Bands for Your Event</h1>
          <p className="text-xl text-gray-200 mb-8">Connect with talented musicians and create unforgettable experiences</p>
          
          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Input placeholder="Location" className="pl-10" />
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                </div>
                <Input type="date" />
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="All Genres" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Genres</SelectItem>
                    <SelectItem value="rock">Rock</SelectItem>
                    <SelectItem value="jazz">Jazz</SelectItem>
                    <SelectItem value="pop">Pop</SelectItem>
                    <SelectItem value="country">Country</SelectItem>
                    <SelectItem value="electronic">Electronic</SelectItem>
                  </SelectContent>
                </Select>
                <Link href="/search-bands">
                  <Button className="w-full bg-primary hover:bg-indigo-700">
                    <Search className="mr-2 h-4 w-4" />
                    Search Bands
                  </Button>
                </Link>
              </div>
              <div className="flex flex-wrap gap-2 mt-4">
                <Button variant="ghost" size="sm" className="rounded-full">Wedding Bands</Button>
                <Button variant="ghost" size="sm" className="rounded-full">Corporate Events</Button>
                <Button variant="ghost" size="sm" className="rounded-full">Festival Acts</Button>
                <Button variant="ghost" size="sm" className="rounded-full">Private Parties</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Featured Bands */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Featured Bands</h2>
          <Link href="/search-bands">
            <Button variant="ghost">View All →</Button>
          </Link>
        </div>
        
        {bandsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="w-full h-48 bg-gray-200 rounded-t-lg"></div>
                <CardContent className="p-4 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {(featuredBands as Band[]).slice(0, 8).map((band) => (
              <BandCard key={band.id} band={band} />
            ))}
          </div>
        )}
      </div>

      {/* Dashboard Section */}
      <div className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Your Booking Dashboard</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Upcoming Bookings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Upcoming Bookings
                  <Badge variant="secondary">{upcomingBookings.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {bookingsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2 mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </div>
                    ))}
                  </div>
                ) : upcomingBookings.length === 0 ? (
                  <div className="text-center py-8">
                    <Calendar className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-gray-500">No upcoming bookings</p>
                    <Link href="/search-bands">
                      <Button size="sm" className="mt-2">Book a Band</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {(upcomingBookings as Booking[]).slice(0, 3).map((booking) => (
                      <div key={booking.id} className="border-l-4 border-green-500 bg-green-50 p-4 rounded-r-lg">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold text-gray-900">Booking #{booking.id}</h4>
                            <p className="text-sm text-gray-600">{booking.venueAddress}</p>
                            <p className="text-sm text-gray-500">
                              {new Date(booking.eventDate).toLocaleDateString()} - {booking.eventTime}
                            </p>
                          </div>
                          <Badge variant={booking.status === 'confirmed' ? 'default' : 'secondary'}>
                            {booking.status}
                          </Badge>
                        </div>
                        <div className="mt-2 flex space-x-2">
                          <Button size="sm" variant="outline">Details</Button>
                          <Button size="sm">Message</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Calendar */}
            <Card>
              <CardHeader>
                <CardTitle>Calendar Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <CalendarView bookings={upcomingBookings as Booking[]} />
              </CardContent>
            </Card>

            {/* Recent Messages */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Messages
                  <Link href="/messages">
                    <Button variant="ghost" size="sm">View All</Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {messagesLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="flex space-x-3 animate-pulse">
                        <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : recentMessages.length === 0 ? (
                  <div className="text-center py-8">
                    <MessageCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-gray-500">No messages yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {(recentMessages as Message[]).slice(0, 3).map((message) => (
                      <div key={message.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                          <MessageCircle className="h-5 w-5 text-gray-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-medium text-gray-900">Message</h4>
                            <span className="text-xs text-gray-500">
                              {new Date(message.createdAt!).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 truncate">{message.content}</p>
                          {!message.isRead && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full mt-1"></div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
