import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calendar, MapPin, Clock, Users, CreditCard, CheckCircle, Lock } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertBookingSchema } from "@shared/schema";
import type { Band } from "@shared/schema";

const bookingFormSchema = insertBookingSchema.extend({
  eventDate: z.string().min(1, "Event date is required"),
  eventTime: z.string().min(1, "Event time is required"),
  venueAddress: z.string().min(1, "Venue address is required"),
  eventType: z.string().min(1, "Event type is required"),
  expectedGuests: z.number().min(1, "Number of guests is required"),
});

type BookingFormData = z.infer<typeof bookingFormSchema>;

type BookingStep = "details" | "payment" | "confirmation";

export default function BookingFlow() {
  const { bandId } = useParams();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState<BookingStep>("details");
  const [paymentMethod, setPaymentMethod] = useState<string>("");

  const { data: band, isLoading } = useQuery<Band>({
    queryKey: [`/api/bands/${bandId}`],
  });

  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      bandId: Number(bandId),
      eventDate: "",
      eventTime: "",
      eventType: "",
      expectedGuests: 0,
      specialRequirements: "",
      venueAddress: "",
      totalAmount: "0",
      platformFee: "0",
      processingFee: "0",
    },
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingFormData) => {
      const response = await apiRequest('POST', '/api/bookings', {
        ...data,
        eventDate: new Date(data.eventDate).toISOString(),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      setCurrentStep("confirmation");
      toast({
        title: "Booking created successfully!",
        description: "Your booking request has been submitted and is pending confirmation.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Booking failed",
        description: "There was an error creating your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const processPaymentMutation = useMutation({
    mutationFn: async (paymentData: any) => {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      return { success: true, transactionId: 'tx_' + Math.random().toString(36).substr(2, 9) };
    },
    onSuccess: () => {
      const formData = form.getValues();
      createBookingMutation.mutate(formData);
    },
    onError: () => {
      toast({
        title: "Payment failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Calculate pricing
  const watchedValues = form.watch();
  const bandFee = band ? Number(band.pricePerNight) : 0;
  const platformFee = bandFee * 0.05; // 5% platform fee
  const processingFee = bandFee * 0.03; // 3% processing fee
  const totalAmount = bandFee + platformFee + processingFee;

  // Update form with calculated values
  if (band && form.getValues().totalAmount === "0") {
    form.setValue("totalAmount", totalAmount.toString());
    form.setValue("platformFee", platformFee.toString());
    form.setValue("processingFee", processingFee.toString());
  }

  const onSubmit = async (data: BookingFormData) => {
    if (currentStep === "details") {
      setCurrentStep("payment");
    } else if (currentStep === "payment") {
      if (!paymentMethod) {
        toast({
          title: "Payment method required",
          description: "Please select a payment method to continue.",
          variant: "destructive",
        });
        return;
      }
      processPaymentMutation.mutate({
        amount: totalAmount,
        method: paymentMethod,
      });
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-md mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Please log in to continue</h1>
          <p className="text-gray-600 mb-6">You need to be logged in to book a band.</p>
          <Button onClick={() => window.location.href = '/api/login'}>
            Log In
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/2"></div>
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-32 bg-gray-200 rounded"></div>
                <div className="h-10 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (!band) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Band not found</h1>
          <p className="text-gray-600">The band you're trying to book doesn't exist.</p>
        </div>
      </div>
    );
  }

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-8">
      <div className="flex items-center">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
          currentStep === "details" ? "bg-primary text-white" : "bg-gray-300 text-gray-600"
        }`}>
          1
        </div>
        <span className={`ml-2 text-sm font-medium ${
          currentStep === "details" ? "text-primary" : "text-gray-600"
        }`}>
          Event Details
        </span>
      </div>
      <div className="flex-1 h-px bg-gray-300 mx-4"></div>
      <div className="flex items-center">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
          currentStep === "payment" ? "bg-primary text-white" : 
          currentStep === "confirmation" ? "bg-green-500 text-white" : "bg-gray-300 text-gray-600"
        }`}>
          {currentStep === "confirmation" ? <CheckCircle className="h-4 w-4" /> : "2"}
        </div>
        <span className={`ml-2 text-sm font-medium ${
          currentStep === "payment" || currentStep === "confirmation" ? "text-primary" : "text-gray-600"
        }`}>
          Payment
        </span>
      </div>
      <div className="flex-1 h-px bg-gray-300 mx-4"></div>
      <div className="flex items-center">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
          currentStep === "confirmation" ? "bg-primary text-white" : "bg-gray-300 text-gray-600"
        }`}>
          {currentStep === "confirmation" ? <CheckCircle className="h-4 w-4" /> : "3"}
        </div>
        <span className={`ml-2 text-sm font-medium ${
          currentStep === "confirmation" ? "text-primary" : "text-gray-600"
        }`}>
          Confirmation
        </span>
      </div>
    </div>
  );

  const renderEventDetailsStep = () => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Event Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="eventDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Event Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="eventTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Event Time</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="venueAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Venue Address</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter venue name and full address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="eventType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Event Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select event type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="wedding">Wedding</SelectItem>
                            <SelectItem value="corporate">Corporate Event</SelectItem>
                            <SelectItem value="private">Private Party</SelectItem>
                            <SelectItem value="festival">Festival</SelectItem>
                            <SelectItem value="club">Club/Bar</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="expectedGuests"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Expected Guests</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="Number of guests"
                            {...field}
                            onChange={(e) => field.onChange(Number(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="specialRequirements"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Special Requirements (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          rows={4}
                          placeholder="Any special requests, technical requirements, or additional information..."
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-between">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setLocation('/')}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">
                    Continue to Payment
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      <div>
        <Card>
          <CardHeader>
            <CardTitle>Booking Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3">
              <img 
                src={band.profileImages?.[0] || "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=100&h=100"} 
                alt={band.name}
                className="w-16 h-16 rounded-lg object-cover"
              />
              <div>
                <h3 className="font-semibold">{band.name}</h3>
                <p className="text-sm text-gray-600">{band.genres.join(", ")}</p>
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="h-3 w-3 mr-1" />
                  {band.location}
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Band Fee</span>
                <span className="font-medium">₦{bandFee.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Platform Fee (5%)</span>
                <span className="font-medium">₦{platformFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Processing Fee (3%)</span>
                <span className="font-medium">₦{processingFee.toFixed(2)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span className="text-primary">₦{totalAmount.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderPaymentStep = () => (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lock className="h-5 w-5 mr-2" />
            Secure Payment Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <Label className="text-base font-medium">Payment Method</Label>
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="credit-card"
                    name="payment-method"
                    value="credit-card"
                    checked={paymentMethod === "credit-card"}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="border-gray-300 text-primary focus:ring-primary"
                  />
                  <Label htmlFor="credit-card" className="flex items-center cursor-pointer">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Credit/Debit Card
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="paypal"
                    name="payment-method"
                    value="paypal"
                    checked={paymentMethod === "paypal"}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="border-gray-300 text-primary focus:ring-primary"
                  />
                  <Label htmlFor="paypal" className="cursor-pointer">PayPal</Label>
                </div>
              </div>
            </div>

            {paymentMethod === "credit-card" && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="card-number">Card Number</Label>
                  <Input
                    id="card-number"
                    placeholder="1234 5678 9012 3456"
                    className="mt-1"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiry">Expiry Date</Label>
                    <Input
                      id="expiry"
                      placeholder="MM/YY"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cvc">CVC</Label>
                    <Input
                      id="cvc"
                      placeholder="123"
                      className="mt-1"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="cardholder-name">Cardholder Name</Label>
                  <Input
                    id="cardholder-name"
                    placeholder="John Doe"
                    className="mt-1"
                  />
                </div>
              </div>
            )}

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center font-bold">
                <span>Total Amount</span>
                <span className="text-primary text-xl">₦{totalAmount.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-between">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setCurrentStep("details")}
              >
                Back to Details
              </Button>
              <Button 
                type="submit"
                disabled={processPaymentMutation.isPending}
              >
                {processPaymentMutation.isPending ? (
                  "Processing Payment..."
                ) : (
                  <>
                    <Lock className="h-4 w-4 mr-2" />
                    Pay Securely
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );

  const renderConfirmationStep = () => (
    <div className="max-w-2xl mx-auto text-center">
      <Card>
        <CardContent className="p-8">
          <div className="mb-6">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h2>
            <p className="text-gray-600">
              Your booking request has been submitted successfully. The band will review your request and respond within 24 hours.
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold mb-4">Booking Details</h3>
            <div className="space-y-2 text-sm text-left">
              <div className="flex justify-between">
                <span>Band:</span>
                <span className="font-medium">{band.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Event Date:</span>
                <span className="font-medium">{watchedValues.eventDate}</span>
              </div>
              <div className="flex justify-between">
                <span>Event Time:</span>
                <span className="font-medium">{watchedValues.eventTime}</span>
              </div>
              <div className="flex justify-between">
                <span>Event Type:</span>
                <span className="font-medium">{watchedValues.eventType}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Amount:</span>
                <span className="font-bold text-primary">${totalAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              You will receive an email confirmation shortly. You can track the status of your booking in your dashboard.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button onClick={() => setLocation('/dashboard')}>
                View Dashboard
              </Button>
              <Button variant="outline" onClick={() => setLocation('/')}>
                Return Home
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Book {band.name}</h1>
          <p className="text-gray-600">Complete your booking in a few simple steps</p>
        </div>

        {renderStepIndicator()}

        {currentStep === "details" && renderEventDetailsStep()}
        {currentStep === "payment" && renderPaymentStep()}
        {currentStep === "confirmation" && renderConfirmationStep()}
      </div>
    </div>
  );
}
